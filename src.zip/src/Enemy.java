import java.awt.*;

// Enemy class
class Enemy extends Entity {
    private double speed;
    private long lastMoveTime;
    private int personality;

    public Enemy(int x, int y, double speed, Color color) {
        super(x, y, color);
        this.speed = speed;
        this.lastMoveTime = System.currentTimeMillis();
        this.personality = (int)(Math.random() * 3); // 0=chaser, 1=wanderer, 2=ambusher
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public void update(Player player, Maze maze) {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastMoveTime < 1000 / speed) {
            return;
        }

        lastMoveTime = currentTime;

        // Different behaviors based on personality
        switch (personality) {
            case 0: // Chaser - direct pursuit
                chasePlayer(player, maze);
                break;
            case 1: // Wanderer - mostly random movement
                if (Math.random() < 0.2) { // 20% chance to chase
                    chasePlayer(player, maze);
                } else {
                    moveRandomly(maze);
                }
                break;
            case 2: // Ambusher - tries to predict player movement
                ambushPlayer(player, maze);
                break;
        }
    }

    private void chasePlayer(Player player, Maze maze) {
        // Simple AI: try to move toward the player
        int dx = 0, dy = 0;

        // Determine direction toward player
        if (player.getX() < x && !maze.isWall(x - 1, y)) dx = -1;
        else if (player.getX() > x && !maze.isWall(x + 1, y)) dx = 1;
        else if (player.getY() < y && !maze.isWall(x, y - 1)) dy = -1;
        else if (player.getY() > y && !maze.isWall(x, y + 1)) dy = 1;

        // If can't move toward player, try random move
        if (dx == 0 && dy == 0) {
            moveRandomly(maze);
        } else {
            x += dx;
            y += dy;
        }
    }

    private void ambushPlayer(Player player, Maze maze) {
        // Try to predict where the player is going and intercept
        int playerX = player.getX();
        int playerY = player.getY();

        // Calculate player direction (very simple prediction)
        int targetX = playerX + (playerX - x) / 2;
        int targetY = playerY + (playerY - y) / 2;

        // Move toward the predicted position
        int dx = 0, dy = 0;

        if (targetX < x && !maze.isWall(x - 1, y)) dx = -1;
        else if (targetX > x && !maze.isWall(x + 1, y)) dx = 1;
        else if (targetY < y && !maze.isWall(x, y - 1)) dy = -1;
        else if (targetY > y && !maze.isWall(x, y + 1)) dy = 1;

        if (dx == 0 && dy == 0) {
            moveRandomly(maze);
        } else {
            x += dx;
            y += dy;
        }
    }

    private void moveRandomly(Maze maze) {
        // Try up to 4 times to find a valid move
        for (int i = 0; i < 4; i++) {
            int direction = (int)(Math.random() * 4);
            int dx = 0, dy = 0;

            switch (direction) {
                case 0: dx = -1; break; // Left
                case 1: dx = 1; break;  // Right
                case 2: dy = -1; break; // Up
                case 3: dy = 1; break;  // Down
            }

            if (!maze.isWall(x + dx, y + dy)) {
                x += dx;
                y += dy;
                return;
            }
        }
    }

    @Override
    public void draw(Graphics2D g) {
        int cellSize = 30;
        g.setColor(color);

        // Different shapes based on personality
        switch (personality) {
            case 0: // Chaser - Square
                g.fillRect(x * cellSize + 5, y * cellSize + 5, cellSize - 10, cellSize - 10);
                break;
            case 1: // Wanderer - Diamond
                int[] xPoints = {
                        x * cellSize + cellSize/2,
                        x * cellSize + cellSize - 5,
                        x * cellSize + cellSize/2,
                        x * cellSize + 5
                };
                int[] yPoints = {
                        y * cellSize + 5,
                        y * cellSize + cellSize/2,
                        y * cellSize + cellSize - 5,
                        y * cellSize + cellSize/2
                };
                g.fillPolygon(xPoints, yPoints, 4);
                break;
            case 2: // Ambusher - Triangle
                int[] xPoints2 = {
                        x * cellSize + cellSize/2,
                        x * cellSize + cellSize - 5,
                        x * cellSize + 5
                };
                int[] yPoints2 = {
                        y * cellSize + 5,
                        y * cellSize + cellSize - 5,
                        y * cellSize + cellSize - 5
                };
                g.fillPolygon(xPoints2, yPoints2, 3);
                break;
        }
    }
}